"""ComfyUI adapter tests."""
